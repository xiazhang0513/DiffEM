#include<iostream>
#include<fstream>
#include<set>
#include<map>
#include<algorithm>
#include<cstdio>
#include<string>
#include<iomanip>
using namespace std;

string p1="mix_chr";
string p2="_m?_hm_high.txt";
set<long long > mset;
int res=0;
string name;
long long ii;
double vv;
int main()
{
    ios::sync_with_stdio(0);
    int left,right;
    cout<<"please input left right(two integers,including left right,splited by a space):"<<endl;
    cin>>left>>right;
    for(int d=left; d<=right; d++)
    {
        string path=p1;
        string num="";
        if(d>99)
        {
            num+=d/100+'0';
        }
        if(d>9)
        {
            num+=d%100/10+'0';
        }
        num+=d%10+'0';

        path+=num;
        path+=p2;
        string outpath="mix_overlap_chr";
        outpath+=num;
        outpath+=".txt";
        ofstream fout(outpath.c_str());

        for(char i='1'; i<='6'; i++)
        {
            mset.clear();
            res=0;
            int pos=path.find('?');
            path[pos]=i;
            ifstream f1(path.c_str());
            path[pos]='?';
            if(!f1)
            {
                cout<<"Can not find "+path<<endl;
                continue;
            }

            while(f1>>name)
            {
                f1>>ii>>vv;
                mset.insert(ii);
            }
            f1.close();
            for(char j=i+1; j<='6'; j++)
            {
                res=0;
                int pos=path.find('?');
                path[pos]=j;
                ifstream f2(path.c_str());
                path[pos]='?';
                while(f2>>name)
                {
                    f2>>ii>>vv;
                    if(mset.count(ii))res++;
                }
                f2.close();
                fout<<i<<"\t"<<j<<"\t"<<res<<endl;
            }
        }
        fout.close();
    }
    return 0;
}

//71849
//74151
//72109
//71970
//73853
