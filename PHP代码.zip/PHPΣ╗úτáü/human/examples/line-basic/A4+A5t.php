
<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Highcharts Example</title>

		<script type="text/javascript" src="../../jquery-1.10.1.min.js"></script>
		<script type="text/javascript">
	
$(function () {
    $('#container').highcharts({
        title: {
            text: 'Monthly Average Temperature',
            x: -20 //center
        },
        subtitle: {
            text: 'Source: WorldClimate.com',
            x: -20
        },
        xAxis: {
            categories: ['1500bp', '1750bp','200bp','2250bp','2500bp']
        },
        yAxis: {
            title: {
                text: 'Temperature (°C)'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: '°C'
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        series: [{
            name: 'ALMer 4-mer',
            data: [97.6,97.92,98.04,98.06,98.09]
        }, {
            name: 'ALMer 5-mer',
            data: [97.65,97.98,98.11,98.21,98.27]
        }]
    });
});
	

		</script>
	</head>
	<body>
<script src="../../js/highcharts.js"></script>
<script src="../../js/modules/exporting.js"></script>
<script src="../../js/themes/grid.js"></script>
<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>

	</body>			
    <!--[{
            name: 'ALmer 4_mer',
            data: [97.6,97.92,98.04,98.05,98.09]
        }, {
            name: 'ALmer 5_mer',
            data: [97.83,98.10,98.14,98.16,98.29]
        }]
	-->
</html>
